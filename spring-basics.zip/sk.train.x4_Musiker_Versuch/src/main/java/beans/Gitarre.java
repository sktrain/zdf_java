package beans;

import org.springframework.stereotype.Component;

import ifaces.Instrument;

@Component
//@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class Gitarre implements Instrument{
	
	public Gitarre(){
		super();
	}
	
	public void play() {
		System.out.println("Gitarrenklänge");
	}
}