package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import ifaces.Performer;

public class Application {
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext("beans")) {
			
			//mal das Orchester bauen
			Performer klavierspieler1 = ctx.getBean(Performer.class);
			Performer klavierspieler2 = ctx.getBean(Performer.class);
			Performer klavierspieler3 = ctx.getBean(Performer.class);
			
			klavierspieler1.perform();
			klavierspieler2.perform();
			klavierspieler3.perform();
			
			
			
			
			
			


			
		}
	}
}
