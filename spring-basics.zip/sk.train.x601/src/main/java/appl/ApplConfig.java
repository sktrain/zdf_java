package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.DiffServiceImpl;
import beans.MathServiceImpl;
import beans.SumServiceImpl;
import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.Log;

@Configuration
public class ApplConfig {
	
	public ApplConfig() {
		Log.log();
	}
	
	

	@Bean(name="sum")
	public SumService sumService() {
		Log.log();
		return new SumServiceImpl();
	}
	
	@Bean
	public SumService sumService2() {
		Log.log();
		return new SumServiceImpl();
	}
	@Bean
	public DiffService diffService() {
		Log.log();
		return new DiffServiceImpl();
	}
	
	@Bean
	public MathService mathService() {
		Log.log();
		return new MathServiceImpl(this.sumService2(), this.diffService());
	}
}
