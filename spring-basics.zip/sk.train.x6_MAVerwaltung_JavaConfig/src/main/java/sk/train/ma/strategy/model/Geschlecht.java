package sk.train.ma.strategy.model;

public enum Geschlecht { W, M, D

}
