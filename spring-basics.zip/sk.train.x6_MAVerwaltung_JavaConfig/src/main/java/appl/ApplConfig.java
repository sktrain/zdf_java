package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import sk.train.ma.strategy.gui.TableModelMAListe;
import sk.train.ma.strategy.model.Mitarbeiter;
import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltung;
import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltungIf;

import java.util.Comparator;
import java.util.List;

import javax.swing.table.TableModel;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;


@Configuration
public class ApplConfig {
	
	public ApplConfig() {
	}
	
	@Bean(name="verwaltung")
	@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON) //default passt
	public MitarbeiterVerwaltungIf getVerwaltung() {
		return new MitarbeiterVerwaltung();
	}
	
	@Bean(name="tablemodel")
	public TableModel getModel() {
		return new TableModelMAListe(getVerwaltung().getMlist(Comparator.naturalOrder()));
	}
	
}
