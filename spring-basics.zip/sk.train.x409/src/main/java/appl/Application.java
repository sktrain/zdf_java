package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			
			final MathService mathService = ctx.getBean(MathService.class);
			System.out.println(mathService.sum(40, 2));
			System.out.println(mathService.diff(80, 3));

			final SumService sumService = ctx.getBean(SumService.class);
			System.out.println(sumService.sum(40, 2));

			final DiffService diffService = ctx.getBean(DiffService.class);
			System.out.println(diffService.diff(80, 3));
		}
	}
}
