package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Zoo;

public class Application {
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml")) {
			final Zoo zoo = ctx.getBean(Zoo.class);
			zoo.print();
		}
	}
}
