package beans;

import jn.util.Log;

public class Language {

	public final String name;
	public final String designer;
	
	public Language(String name, String designer) {
		Log.log(name, designer);
		this.name = name;
		this.designer = designer;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " [" + name + ", " + designer + "]";
	}
}
