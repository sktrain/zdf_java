package beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

import ifaces.DiffService;
import jn.util.Log;

@Component
public class DiffServiceImpl implements DiffService {
	public DiffServiceImpl() { 
		Log.log();
	}
	@PostConstruct
	public void postConstruct() {
		Log.log();
	}
	@PreDestroy
	public void preDestroy() {
		Log.log();
	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
