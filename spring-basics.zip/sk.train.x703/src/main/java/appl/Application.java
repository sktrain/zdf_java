package appl;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
	public static void main(String[] args) {
		final ConfigurableApplicationContext ctx = 
				new AnnotationConfigApplicationContext("beans");
		ctx.registerShutdownHook();
		
		
		
		new MathUI(ctx).setVisible(true);

		ctx.addApplicationListener((MathEvent event) ->
				{System.out.println("MathEvent  : " + event);
				 System.out.println(Thread.currentThread());
				 });
		ctx.addApplicationListener((SumEvent event) -> 
				System.out.println("SumEvent   : " + event.x + " " + event.y));
		ctx.addApplicationListener((ErrorEvent event) -> 
				System.out.println("ErrorEvent : " + event));
	}
}
