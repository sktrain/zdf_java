package appl;

public class ErrorEvent extends MathEvent {

	private static final long serialVersionUID = 1L;

	public ErrorEvent(Object source) {
		super(source);
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " []";
	}
}
