package beans;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import ifaces.DiffService;
import jn.util.Log;
import sk.train.KarrersAnnotation;

//@Component
//@Service
@KarrersAnnotation
public class DiffServiceImpl implements DiffService {
	public DiffServiceImpl() {  
		Log.log();
	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
