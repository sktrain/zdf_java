package appl;

import java.util.Comparator;

import javax.swing.table.TableModel;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import sk.train.ma.strategy.gui.TableModelMAListe;
import sk.train.ma.strategy.model.GehaltsmodellFactory;
import sk.train.ma.strategy.model.GehaltsmodellFactoryIf;
import sk.train.ma.strategy.store.MitarbeiterStoreService;
import sk.train.ma.strategy.store.MitarbeiterStoreServiceIf;
import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltung;
import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltungIf;


@Configuration
@PropertySource("classpath:factory.properties")
public class ApplConfig {
	
	public ApplConfig() {
	}
	
	@Bean(name="generator")
	public GehaltsmodellFactoryIf getFactory() {
		return new GehaltsmodellFactory();
	}
	
	@Bean(name="store")
	public MitarbeiterStoreServiceIf getStoreService() {
		return new MitarbeiterStoreService(getFactory());
	}
	
	@Bean(name="verwaltung")
	public MitarbeiterVerwaltungIf getVerwaltung() {
		return new MitarbeiterVerwaltung(getStoreService());
	}
	
	@Bean(name="tablemodel")
	public TableModel getModel() {
		return new TableModelMAListe(getVerwaltung().getMlist(Comparator.naturalOrder()));
	}
	
}
