package sk.train.ma.strategy.model;

public interface GehaltsmodellFactoryIf {

	Gehaltsmodell getGehaltsmodell(String type);

}