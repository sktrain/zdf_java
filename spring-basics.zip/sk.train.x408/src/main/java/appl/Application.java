package appl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import beans.Genre;
import ifaces.MathService;
import jn.util.Log;

@Component
public class Application {
	
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("appl", "beans")) {
			final Application application = ctx.getBean(Application.class);
			application.run();
		}
	}

    @Resource  (name = "mathServiceSimple")
	//@Autowired
	private MathService math;

//	private MathService mathServiceSimple;
//
//	@Resource(name = "mathServiceSimple")
//	public void setMathServiceSimple(MathService mathService) {
//		Log.log(mathService);
//		this.mathServiceSimple = mathService;
//	}

//	@Resource(name = "mathServiceRecursive")
//	private MathService mathServiceRecursive;

	private MathService mathServiceRecursive;

	// @Resource(name = "mathServiceRecursive")
	@Autowired
	@Genre(value="X")
	public void setMathServiceRecursive(MathService mathService) {
		Log.log(mathService);
		this.mathServiceRecursive = mathService;
	}

	private void run() {
		System.out.println(math.sum(40, 2));
		System.out.println(math.diff(80, 3));
		System.out.println(mathServiceRecursive.sum(40, 2));
		System.out.println(mathServiceRecursive.diff(80, 3));
	}
}
