/*	Berechnung der Anzahl der positiven, negativen und 0-Werte in einem gegebenen Array mittels 
 *  eines Stream-Durchlaufs.
 *  (Hinweis: geht mit vorhandenen Collectoren aber auch mit selbstgeschriebenem Collector) 
 */

package Aufgaben_Karrer;

import java.util.stream.IntStream;

public class PosNegCounter_MyCollector {

	public static void main(String[] args) {

     IntStream si =  IntStream.of(1, -2, 4, 5, 7, -8, 0);
     
     //todo: .....  
	
	}
}

