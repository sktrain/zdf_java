/* Berechnung des Produkts der positiven Ganzzahlen von 1 bis 100 (Fakult�t)
 * und der Summe dieser Zahlen in einem Stream-Durchlauf mittels eigenem Reducer
*/

package Aufgaben_Karrer;

import java.math.BigInteger;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Reduce_Sum_Fak {

	public static void main(String[] args) {

		IntStream is = IntStream.range(1, 100);
		//bei Bedarf: Stream bs = is.mapToObj(i -> BigInteger.valueOf(i));
		
		//todo: ...
	}
}

