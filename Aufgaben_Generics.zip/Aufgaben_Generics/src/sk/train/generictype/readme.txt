Stack soll auf die Verwendung von Generics umgestellt werden. 
So nebenbei k�nnte noch das Speicherproblem (memory leak) beseitigt werden.
